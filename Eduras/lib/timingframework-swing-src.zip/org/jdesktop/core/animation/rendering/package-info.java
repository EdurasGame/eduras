/**
 * Core classes of a rendering framework that can support
 * both passive and active rendering approaches.
 */
package org.jdesktop.core.animation.rendering;